package martin.rivera.packsnpaws

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CuidadorProfile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cuidador_profile)
    }
}